const Discord = require("discord.js");
const send = require("../../utils/sendMessage.js")
const { PermissionFlagsBits } = require("discord.js");
module.exports = {
    name: "searchplay",
    aliases: ['sp'],
    accessableby: "Manage Messages",
    description: "Check ping of the bot",
    usage: ">>play",
    example: ">>play ",
    cooldown: 5,
    category: "Music",
    options: [{
        name: "song",
        description: "The song which you want to play",
        required: true,
        type: 3, //https://discord.com/developers/docs/interactions/application-commands#application-command-object-application-command-option-structure
        req: "user"
    }],
    run: async (bot, message, args, options, author) => {
        //Checking for the voicechannel and permissions (you can add more permissions if you like).
        const voice_channel = message.member.voice.channel;
        const vc = new Discord.EmbedBuilder()
        if (!voice_channel) {
            vc.setColor("#FF0000")
            vc.setFooter({ text: "Requested by " + author.tag, iconURL: author.displayAvatarURL() });
            vc.setTitle(`❌ ERROR | Please join a voice channel first`)
            return send(message, { embeds: [vc] })
        };

        const permissions = voice_channel.permissionsFor(message.client.user);
        if (!permissions.has(PermissionFlagsBits.Connect)) return send(message, { content: 'Missing connect premission' });
        if (!permissions.has(PermissionFlagsBits.Speak)) return send(message, { content: 'Missing speak permission' });

        let channel = message.member.voice.channel.id;
        const samevc = new Discord.EmbedBuilder()
        if (bot.distube.getQueue(message) && channel !== message.guild.members.me.voice.channel.id) {
            samevc.setColor("#FF0000")
            samevc.setTitle(`❌ ERROR | Please join my voice channel first`)
            samevc.setDescription(`Channel Name: \`${message.guild.members.me.voice.channel.name}\``)
            return send(message, { embeds: [samevc] })
        };

        const Searchterm = new Discord.EmbedBuilder()
        if (!options[0]) {
            Searchterm.setColor("#FF0000")
            Searchterm.setTitle(`❌ ERROR | You didn't provided a Searchterm`)
            Searchterm.setDescription(`Usage: \`/play <URL / TITLE>\``)
            return send(message, { embeds: [Searchterm] })
        };
        const search = new Discord.EmbedBuilder()
        search.setDescription(":mag: **Searching! **" + options[0])
        search.setColor("#FFFF00");
        send(message, { embeds: [search] })

        const music = options[0];
        let results = await bot.distube.search(music, {
            type: "video",
            limit: 10
        })

        if (!results) {
            return send(message, { content: `No result found for ${music}!` })
        }

        let searchResult = "";

        for (i = 0; i < 10; i++) {
            try {
                searchResult += `**${i + 1})** [${results[i].name}](${results[1].url}) - \`${results[i].formattedDuration}\`\n`
            }
            catch (error) {
                searchResult = "\n";
            }
        }

        const embed = new Discord.EmbedBuilder()
        embed.setTitle(`SearchResults for: ${music}`.substring(0, 256))
        embed.setColor(message.guild.members.me.displayHexColor)
        embed.setDescription(searchResult.substring(0, 2048))
        embed.setFooter({ text: "Enter anything else or wait 60 seconds to cancel" })

        const one = new Discord.ButtonBuilder();
        one.setEmoji("1️⃣");
        one.setStyle(Discord.ButtonStyle.Primary);
        one.setCustomId("1");

        const two = new Discord.ButtonBuilder();
        two.setEmoji("2️⃣");
        two.setStyle(Discord.ButtonStyle.Primary);
        two.setCustomId("2");

        const three = new Discord.ButtonBuilder();
        three.setEmoji("3️⃣");
        three.setStyle(Discord.ButtonStyle.Primary);
        three.setCustomId("3");

        const four = new Discord.ButtonBuilder();
        four.setEmoji("4️⃣");
        four.setStyle(Discord.ButtonStyle.Primary);
        four.setCustomId("4");

        const five = new Discord.ButtonBuilder();
        five.setEmoji("5️⃣");
        five.setStyle(Discord.ButtonStyle.Primary);
        five.setCustomId("5");

        const six = new Discord.ButtonBuilder();
        six.setEmoji("6️⃣");
        six.setStyle(Discord.ButtonStyle.Primary);
        six.setCustomId("6");

        const seven = new Discord.ButtonBuilder();
        seven.setEmoji("7️⃣");
        seven.setStyle(Discord.ButtonStyle.Primary);
        seven.setCustomId("7");

        const eight = new Discord.ButtonBuilder();
        eight.setEmoji("8️⃣");
        eight.setStyle(Discord.ButtonStyle.Primary);
        eight.setCustomId("8");

        const nine = new Discord.ButtonBuilder();
        nine.setEmoji("9️⃣");
        nine.setStyle(Discord.ButtonStyle.Primary);
        nine.setCustomId("9");

        const ten = new Discord.ButtonBuilder();
        ten.setEmoji("🔟");
        ten.setStyle(Discord.ButtonStyle.Primary);
        ten.setCustomId("10");

        const buttonRow = new Discord.ActionRowBuilder().addComponents(one, two, three, four, five);
        const buttonRow1 = new Discord.ActionRowBuilder().addComponents(six, seven, eight, nine, ten);
        const m = await send(message, { embeds: [embed], components: [buttonRow, buttonRow1] }, false, true);
        const filter = i => i.user.id === author.id
        const collector = m.createMessageComponentCollector({
            componentType: Discord.ComponentType.Button,
            filter,
            max: 1,
            time: 30_000,
        });

        collector.on("collect", (interaction) => {
            let userinput = interaction.customId;
            if (Number(userinput) <= 0 || Number(userinput) > 10 || isNaN(parseInt(userinput))) {
                return interaction.reply({ content: "You answered an invalid number!" });
            }
            bot.distube.play(interaction.member.voice.channel, results[userinput - 1].url, {
                member: interaction.member,
                textChannel: interaction.channel,
            })
        })

        collector.on("end", async (interaction) => {
            await m.edit({ embeds: [embed], components: [] });

        })
    }
}